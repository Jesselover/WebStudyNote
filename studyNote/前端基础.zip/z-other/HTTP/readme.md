> [!NOTE]
> 「HTTP 协议原理与应用」学习笔记，课程来自：[慕课网](https://coding.imooc.com/class/225.html)  
> 
> 视频只是作为辅助，深入详细学习HTTP建议阅读文档和书籍。  
> 推荐文档：MDN  
> 推荐书籍：HTTP权威指南、图解HTTP

- [ch01. HTTP 协议基础及发展历史](01%20HTTP%20基础及发展历史.md)
- [ch02. HTTP 各种特性总览](02%20HTTP%20各种特性总览.md)
- [ch03. Nginx 代理以及面向未来的 HTTP](03%20Nginx%20代理以及面向未来的%20HTTP.md)
- [ch04. 课程总结](前端基础/z-other/HTTP/ch04.md)


