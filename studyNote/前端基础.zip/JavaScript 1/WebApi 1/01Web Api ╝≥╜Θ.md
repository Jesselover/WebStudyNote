# （一）Web Api 简介

## 1. Web APIs 和 JS 基础关联性

### 1.1 JS 组成

- ECMAScript: JS 语法
- BOM: Web API
- DOM: Web API

## 2. API 和 Web API

### 2.1 API

API：Application Programming Interface，应用程序接口。

### 2.2 Web API 

Web API 是浏览器提供得一套操作浏览器功能和页面元素得 API（BOM 和 DOM）。


