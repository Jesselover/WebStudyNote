
> [!NOTE]
> 本章前端WebApi笔记根据 [B站pink老师前端教学视频](https://www.bilibili.com/video/BV1Sy4y1C7ha?from=search&seid=3281043067191613773) 记录。

- [ch01. WebApi简介](01Web%20Api%20简介.md)
- [ch02. DOM](02DOM%20基础.md)
- [ch03. 事件高级](03事件高级.md)
- [ch04. BOM 基础](04BOM.md)
- [ch05. PC端网页特效](05PC%20端网页特效.md)
- [ch06. 移动端网页特效](06移动端网页特效.md)
- [ch07. 本地存储](07.%20%20window.xxxStorage.md)