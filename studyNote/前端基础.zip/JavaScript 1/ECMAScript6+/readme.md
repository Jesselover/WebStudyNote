本笔记对应课程：[尚硅谷Web前端ES6教程，涵盖ES6-ES11](https://www.bilibili.com/video/BV1uK411H7on)  

另外，有些地方老师讲的还是浅了，要深入的话，还是建议去看阮一峰的《ES6标准入门》这本书。
> 《ES6标准入门》在线阅读链接：https://es6.ruanyifeng.com

- [ch01. ECMAScript 相关介绍](前端基础/JavaScript%201/ECMAScript6+/ch01.md)
- [ch02. ECMASript 6 新特性](前端基础/JavaScript%201/ECMAScript6+/ch02.md)
- [ch03. ECMASript 7 新特性](前端基础/JavaScript%201/ECMAScript6+/ch03.md)
- [ch04. ECMASript 8 新特性](前端基础/JavaScript%201/ECMAScript6+/ch04.md)
- [ch06. ECMASript 10 新特性](前端基础/JavaScript%201/ECMAScript6+/ch06.md)
- [ch07. ECMASript 11 新特性](前端基础/JavaScript%201/ECMAScript6+/ch07.md)
