> [!TIP]
> JavaScript高级部分，包含面向对象、原型链、进阶数组方法、高阶函数、闭包和部分ES6等知识。本笔记对应课程：[pink老师-javaScript进阶](https://www.bilibili.com/video/BV1Kt411w7MP)

- [ch01. JavaScript 面向对象](01avaScript%20面向对象.md)
- [ch02. 构造函数和原型](02构造函数和原型.md)
- [ch03. 函数进阶](03函数进阶.md)
- [ch04. 正则表达式](04正则表达式.md)